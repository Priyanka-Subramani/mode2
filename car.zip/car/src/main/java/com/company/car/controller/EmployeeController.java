package com.company.car.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.car.dto.EmployeeRequestDto;
import com.company.car.model.Employee;
import com.company.car.service.EmployeeService;
import com.company.car.service.OrganisationService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	OrganisationService organisationService;
	
	
	@PostMapping("/employee")
	public void saveEmployee(@RequestBody EmployeeRequestDto employeeRequestDto) {
		employeeService.saveEmployee(employeeRequestDto);
	}
	
	@GetMapping("/employee/{sapId}")
	public Employee getEmployeeDetails(@PathVariable(value = "sapId") Long sapId)
	{
		return employeeService.getEmployee(sapId);
	}
	
	@GetMapping("/salary")
	public List<Employee> getEmployeeDetails(@RequestParam double salary)
	{
		System.out.println(salary);
		 System.out.println(employeeService.getEmployeeDetails(salary).get(0));
		 return employeeService.getEmployeeDetails(salary);
	}
	
	@PatchMapping("/patch/{sapId}")
	public ResponseEntity < ? > updateResource(@RequestParam("phoneNumber") long phoneNumber, @PathVariable("sapId") long sapId) {
		 Employee newEmployee = employeeService.updateEmployee(phoneNumber, sapId);
		 return new ResponseEntity < > (newEmployee, HttpStatus.OK);
		}
	
}
