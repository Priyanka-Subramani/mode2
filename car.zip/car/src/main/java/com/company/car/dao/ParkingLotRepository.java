package com.company.car.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.car.model.ParkingLot;

@Repository
public interface ParkingLotRepository extends CrudRepository<ParkingLot, Long> {

}
