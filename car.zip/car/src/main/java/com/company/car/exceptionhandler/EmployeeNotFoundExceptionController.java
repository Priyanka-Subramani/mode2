package com.company.car.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.company.car.exception.EmployeeNotFoundException;

@ControllerAdvice
public class EmployeeNotFoundExceptionController extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<Error> handleException(EmployeeNotFoundException exception) {
		
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("Please retry with correct SAPID");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}

}
