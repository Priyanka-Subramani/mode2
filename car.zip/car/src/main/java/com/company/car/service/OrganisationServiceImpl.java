package com.company.car.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.car.dao.OrganisationRepository;
import com.company.car.exception.EmployeeNotFoundException;
import com.company.car.model.Employee;
import com.company.car.model.Organisation;
import com.company.car.utility.OrganisationHelperClass;

@Service
public class OrganisationServiceImpl implements OrganisationService {

	@Autowired
	OrganisationRepository organisationRepository;
	
	@Override
	public void saveOrganisation(Employee employee) {
		Organisation organisation=new Organisation();
		organisation.setSapId(employee.getSapId());
		organisation.setDesignation(OrganisationHelperClass.getDesignation());
		organisation.setSalary(OrganisationHelperClass.generateSalary());
		organisation.setDoj((LocalDate.of(2019, 8, 20)));
		organisation.setCompanyMailId(employee.getName()+"@hcl.com");
		organisation.setProject("ABC");
		
		organisationRepository.save(organisation);
	}
	
	@Override
	public Organisation getEmployeeDetails(double salary) {
		Optional<Organisation> organisation=organisationRepository.findBySalary(salary);
		if(organisation.isPresent())
			return organisation.get();
		else
			throw new EmployeeNotFoundException("Invalid SAPID");
	}
	
	@Override
	public Organisation getOrganisationDetails(long sapId) {
		Optional<Organisation> organisation= organisationRepository.findById(sapId);
		if(organisation.isPresent())
			return organisation.get();
		else
			throw new EmployeeNotFoundException("Invalid SAPID");
	}
}
