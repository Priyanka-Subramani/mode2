package com.company.car.service;

import java.util.List;

import com.company.car.dto.EmployeeRequestDto;
import com.company.car.model.Employee;

public interface EmployeeService {
	
	public Iterable<Employee> getAllEmployeeDetails();
	public void saveEmployee(EmployeeRequestDto employeeRequestDto);
	public Employee getEmployee(long sapId);
	public String validate(String emailID, String password);
	
	public List<Employee> getEmployeeDetails(double salary);
	
	public Employee updateEmployee(long phoneNumber,long sapId);
	

}
