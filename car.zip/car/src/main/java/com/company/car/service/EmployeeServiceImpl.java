package com.company.car.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.car.dao.EmployeeRepository;
import com.company.car.dto.EmployeeRequestDto;
import com.company.car.exception.EmployeeNotFoundException;
import com.company.car.model.Employee;
import com.company.car.utility.EmployeeHelperClass;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	OrganisationService organisationService;
	
	@Override
	public Iterable<Employee> getAllEmployeeDetails() {
		
		return employeeRepository.findAll();
	}

	@Override
	public void saveEmployee(EmployeeRequestDto employeeRequestDto) {
		Employee employee=new Employee();
		employee.setSapId(EmployeeHelperClass.generateSAPID());
		employee.setName(employeeRequestDto.getName());
		employee.setDob(employeeRequestDto.getDob());
		employee.setPhoneNumber(employeeRequestDto.getPhoneNumber());
		employee.setEmailId(employeeRequestDto.getEmailId());
		employee.setAddress(employeeRequestDto.getAddress());
		employeeRepository.save(employee);
		organisationService.saveOrganisation(employee);
	}
	

	@Override
	public Employee getEmployee(long sapId) {
		Optional<Employee> employee= employeeRepository.findById(sapId);
		if(employee.isPresent())
			return employee.get();
		else
			throw new EmployeeNotFoundException("Invalid SAPID");
	}
		

	@Override
	public String validate(String emailID, String password) {
		
		return null;
	}
	
	@Override
	public List<Employee> getEmployeeDetails(double salary)
	{	List<Employee> employee=employeeRepository.getEmployeeDetails(salary);	
	return employee;
	}
	
	@Override
	public Employee updateEmployee(long phoneNumber,long sapId)
	{
		return employeeRepository.updatePhoneNumber(phoneNumber, sapId);	
	}

}
