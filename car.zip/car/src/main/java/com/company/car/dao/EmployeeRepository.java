package com.company.car.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.car.model.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	
	/*
	 * @Query("select name from Employee where emailID=?1 and password=?2") 
	 * String validateCustomer(String emailID, String password);
	 */
	
	@Query("select e from Employee e,Organisation o where salary>=?1 and e.sapId=o.sapId")
	public List<Employee> getEmployeeDetails(double salary);
	
	@Query("update Employee set phoneNumber=?1 where sapId=?2")
	public Employee updatePhoneNumber(double phoneNumber,long sapId);
			

	

}
