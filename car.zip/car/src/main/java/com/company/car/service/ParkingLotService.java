package com.company.car.service;

public interface ParkingLotService {

}
