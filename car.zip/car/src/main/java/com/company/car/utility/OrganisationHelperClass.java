package com.company.car.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class OrganisationHelperClass {
	
	public static double generateSalary() {
		
		List<Double> list=new ArrayList<Double>();
		list.add(30000.00);
		list.add(40000.00);
		list.add(50000.00);
		list.add(60000.00);
		Random random=new Random();
		return list.get(random.nextInt(list.size()));
	}
	
	public static String getReportingManager() { 
		
		List<String> list=new ArrayList<String>();
		list.add("Zaynab Khathoon");
		list.add("Amit Saurav");
		list.add("Siddhanth Madhur");
		Random random=new Random();
		return list.get(random.nextInt(list.size()));
	}
	
public static String getDesignation() { 
		
		List<String> list=new ArrayList<String>();
		list.add("Software Developer");
		list.add("Tester");
		list.add("Reporting Manager");
		Random random=new Random();
		return list.get(random.nextInt(list.size()));
	}
	
	

}
