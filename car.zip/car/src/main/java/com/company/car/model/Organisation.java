package com.company.car.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Organisation {
	@Id
	private long sapId;
	private String designation;
	private double salary;
	private LocalDate doj;
	private String companyMailId;
	private String project;
	
	public long getSapId() {
		return sapId;
	}
	public void setSapId(long sapId) {
		this.sapId = sapId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getCompanyMailId() {
		return companyMailId;
	}
	public void setCompanyMailId(String companyMailId) {
		this.companyMailId = companyMailId;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	

}
