package com.company.car.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.car.model.Organisation;

@Repository
public interface OrganisationRepository extends CrudRepository<Organisation, Long> {

	Optional<Organisation> findBySalary(double salary);
	
/*	organisations.stream().forEach(organisation -> {
		if(organisation.isPresent()) Employee emp = employeeService.getEmployee(organisations.get)
		});
*/
}
