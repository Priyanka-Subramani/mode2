package com.company.car.utility;

public class EmployeeHelperClass {
	
	static long ID=51830090;
	
	public static long generateSAPID()
	{
		return ID++;
	}

}
