package com.company.car.service;

import com.company.car.model.Employee;
import com.company.car.model.Organisation;

public interface OrganisationService {
	
	public void saveOrganisation(Employee employee);
	public Organisation getEmployeeDetails(double salary);
	
	public Organisation getOrganisationDetails(long sapId);
	

}
