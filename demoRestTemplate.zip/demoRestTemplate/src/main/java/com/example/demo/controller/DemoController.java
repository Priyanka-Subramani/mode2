package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Employee;

@RestController
public class DemoController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/emp")
	public List<Employee> getEmployees()
	{
		List<Employee> list;
		return restTemplate.getForObject("http://CAR/employees/60000.00",List.class);
	}
	
	/*@PatchMapping("patch")
	public Employee updatePhoneNumber()
	{
		List<Employee> list;
		return restTemplate.patchForObject("http://CAR/patch/51830091",List.class);
	}*/

}
