package com.hcl.service;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Transaction;
import org.springframework.stereotype.Service;

import com.hcl.model.Account;
import com.hcl.model.CustomerDetails;
import com.hcl.model.Payee;
import com.hcl.model.Transactions;


public interface BankService 
{
	public String saveCustomer(CustomerDetails customer);
	public List<CustomerDetails> listCustomerDetails(String customerid);
	public String saveAccount(Account account);
	public List<Account> listAccountDetails(String customerid);
	public String savePayee(String name,String customerid,String accountNumber);
	public List<Payee> listPayeeDetails(String customerid) ;
	public String saveTransaction(Transactions transaction);
	public List<Transactions> listTransactionDetails(String accountNumber);
	public int validate(String accountNumber);
	public int validatename(String name);
	public String getFromAccountNumber(String fromAccountNumber);
	public String getToAccountNumber(String toAccountNumber);
	
}
