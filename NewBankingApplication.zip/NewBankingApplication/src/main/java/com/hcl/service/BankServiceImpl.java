package com.hcl.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.hcl.helper.UserHelperClass;
import com.hcl.model.Account;
import com.hcl.model.CompositeKey;
import com.hcl.model.CustomerDetails;
import com.hcl.model.Payee;
import com.hcl.model.Transactions;

@Service
public class BankServiceImpl implements BankService
{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public String saveCustomer(CustomerDetails customer)
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
		  customer.setCustomerID(UserHelperClass.generatecustomerID());
	     
		try {
	         tx = session.beginTransaction();
	         session.save(customer);
	         tx.commit();
	     }
		catch (HibernateException ex) {
	         if (tx!=null) tx.rollback();
	         ex.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
		return customer.getCustomerID();
	}

	@Override
	public List<CustomerDetails> listCustomerDetails(String customerid) 
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
	     List<CustomerDetails> cust=null;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 Query query=session.createQuery("FROM CustomerDetails where customerid=:code");
	    	 query.setParameter("code",customerid );
	    	 cust=query.list();
	    	 tx.commit();
	     }
	    	 catch(HibernateException e)
	    	 {
	    		 if(tx!=null)
	    			 tx.rollback();
	    		 e.printStackTrace();
	    	 }
	     finally
	     {
	    	 session.close();
	     }
		
		return cust;
	}

        @Override
	public String saveAccount(Account account)
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null; 
		try 
		{
			tx = session.beginTransaction();
	         session.save(account);
	         tx.commit();
	     }
		catch (HibernateException ex) {
	         if (tx!=null) tx.rollback();
	         ex.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
		return account.getAccountNumber();
	}

	@Override
	public List<Account> listAccountDetails(String customerid) 
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
	     List<Account> accounts=null;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 Query query=session.createQuery("FROM Account where customerid=:code");
	    	 query.setParameter("code",customerid );
	    	 accounts=query.list();
	    	 tx.commit();
	     }
	    	 catch(HibernateException e)
	    	 {
	    		 if(tx!=null)
	    			 tx.rollback();
	    		 e.printStackTrace();
	    	 }
	     finally
	     {
	    	 session.close();
	     }
		return accounts;
	}

	@Override
	public String savePayee(String name,String customerid,String accountNumber)
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
	     CompositeKey compositekey=new CompositeKey();
	     compositekey.setCustomerID(customerid);
	     compositekey.setBeneficiaryaccountNumber(accountNumber);
	     Payee payee=new Payee();
	     payee.setKey(compositekey);
	     payee.setBeneficiaryName(name);
		try { 
	         tx = session.beginTransaction();
	         session.save(payee);
	         tx.commit();
	     }
		catch (HibernateException ex) {
	         if (tx!=null) tx.rollback();
	         ex.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return payee.getBeneficiaryName();
	}
	
	@Override
	public List<Payee> listPayeeDetails(String customerid) 
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
	     List<Payee> payees=null;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 Query query=session.createQuery("FROM Payee where customerid=:code");
	    	 query.setParameter("code",customerid );
	    	 payees=query.list();
	    	 tx.commit();
	     }
	    	 catch(HibernateException e)
	    	 {
	    		 if(tx!=null)
	    			 tx.rollback();
	    		 e.printStackTrace();
	    	 }
	     finally
	     {
	    	 session.close();
	     }
		return payees;
	}
	
	@Override
	public String saveTransaction(Transactions transaction)
	{
		Account account=new Account();
		 CustomerDetails customer=new CustomerDetails();
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
		try {
			
	         tx = session.beginTransaction();
	         session.save(transaction);
	         tx.commit();
	     }
		catch (HibernateException ex) {
	         if (tx!=null) tx.rollback();
	         ex.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
		return transaction.getTransactionType();
	}
	
	@Override
	public List<Transactions> listTransactionDetails(String accountNumber) 
	{
		 Session session = sessionFactory.openSession();
	     Transaction tx = null;
	     List<Transactions> trans=null;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 Query query=session.createQuery("FROM Transactions where accountNumber=:code");
	    	 query.setParameter("code",accountNumber );
	    	 trans=query.list();
	    	 tx.commit();
	     }
	    	 catch(HibernateException e)
	    	 {
	    		 if(tx!=null)
	    			 tx.rollback();
	    		 e.printStackTrace();
	    	 }
	     finally
	     {
	    	 session.close();
	     }
		return trans;
	}
	
	
	@Override
	public int validate(String accountNumber)
	{
		Session session = sessionFactory.openSession();
	     Transaction tx=null;
	     List<Account> accounts=null;
	     int result=0;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 accounts=session.createQuery("FROM Account").list();
	    	 for(Account acc:accounts)
	    	 {
	    		 if(acc.getAccountNumber().equalsIgnoreCase(accountNumber))
	    			 result=1;
	    	 }
	     }
	     catch (HibernateException e) 
	     {
 	          if(tx!=null) tx.rollback();
 	        	e.printStackTrace();
 	     }
	     finally
	     {
	    	 session.close();
	     }
	     return result;
	}
	
	@Override
	public int validatename(String name)
	{
		Session session = sessionFactory.openSession();
	     Transaction tx=null;
	     List<CustomerDetails> custs=null;
	     int result=0;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 custs=session.createQuery("FROM CustomerDetails").list();
	    	 for(CustomerDetails c:custs)
	    	 {
	    		 if(c.getName().equalsIgnoreCase(name))
	    			 result=1;
	    	 }
	     }
	     catch (HibernateException e) 
	     {
 	          if(tx!=null) tx.rollback();
 	        	e.printStackTrace();
 	     }
	     finally
	     {
	    	 session.close();
	     }
	     return result;
	}
	
	
	@Override
	public String getFromAccountNumber(String fromAccountNumber)
	{
		Transactions transactions=new Transactions();
		Session session = sessionFactory.openSession();
	     Transaction tx=null;
	     List<Account> accounts=null;
	     double bal=0;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 accounts=session.createQuery("FROM Account").list(); 
	    	 for(Account acc:accounts)
	    	 {
	    		 if(acc.getAccountNumber().equalsIgnoreCase(fromAccountNumber))
	    			 bal=acc.getBalance()-transactions.getAmount();
	    			 transactions.setTransactionType("Debit"); 
	    			 System.out.println(bal);
	    	 }
	    	 
	     }
	     catch (HibernateException e) 
	     {
 	          if(tx!=null) tx.rollback();
 	        	e.printStackTrace();
 	     }
	     finally
	     {
	    	 session.close();
	     }
	     return transactions.getTransactionType();
		
	}

	@Override
	public String getToAccountNumber(String toAccountNumber)
	{
		Transactions transactions=new Transactions();
		Session session = sessionFactory.openSession();
	     Transaction tx=null;
	     List<Account> accounts=null;
	     double bal=0;
	     try
	     {
	    	 tx=session.beginTransaction();
	    	 accounts=session.createQuery("FROM Account").list(); 
	    	 for(Account acc:accounts)
	    	 {
	    		 if(acc.getAccountNumber().equalsIgnoreCase(toAccountNumber))
	    			 bal=acc.getBalance()+transactions.getAmount();
	    			 transactions.setTransactionType("Credit"); 
	    			 System.out.println(bal);
	    	 }
	    	 
	     }
	     catch (HibernateException e) 
	     {
 	          if(tx!=null) tx.rollback();
 	        	e.printStackTrace();
 	     }
	     finally
	     {
	    	 session.close();
	     }
	     return transactions.getTransactionType();
		
	}
}