package com.hcl.helper;

import java.util.Random;

import com.hcl.model.CompositeKey;
import com.hcl.model.CustomerDetails;

public class UserHelperClass 
{
	
	static long ID=123001;
	static int custid=12340001;
	static int tid=1;
	public static String generatecustomerID()
	{
		String str="ABC";
		str=str+ID++;
		return str;
	}
	public static String generateAccountNumber()
	{
		String string="SBI";
		string=string+custid++;
		return string;
	}
	
	public static int generateTransactionID()
	{
		return tid++;
	}
	/*public static String generateBeneficiaryaccountNumber()
	{
		Random random=new Random();
		CustomerDetails customer=new CustomerDetails();
		CompositeKey compositekey=new CompositeKey();
		
		for(int i=0;i<customer.getCustomerID().length();i++)
		{
			String beneficiaryaccountNumber= customer.getCustomerID();
					
		}
		return generateBeneficiaryaccountNumber();
	}*/

}
