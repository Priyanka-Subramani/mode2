package com.hcl.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class CompositeKey implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String customerID;
	private String beneficiaryaccountNumber;
	
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getBeneficiaryaccountNumber() {
		return beneficiaryaccountNumber;
	}
	public void setBeneficiaryaccountNumber(String beneficiaryaccountNumber) {
		this.beneficiaryaccountNumber = beneficiaryaccountNumber;
	}
	

}
