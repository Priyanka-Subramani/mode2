package com.hcl.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.helper.UserHelperClass;
import com.hcl.model.Account;
import com.hcl.model.CustomerDetails;
import com.hcl.model.Payee;
import com.hcl.model.Transactions;
import com.hcl.service.BankService;

@Controller
public class UserController 
{
	@Autowired
	BankService bankservice;
	
	
	@RequestMapping("/applicationform")
	public String bookingForm(Model model)
	{
		CustomerDetails customer=new CustomerDetails();
		model.addAttribute("userDetails",customer );
		return "UserApplicationForm";
	}
	
		
	@RequestMapping(value="/submitForm",method =RequestMethod.POST)
	public String display(@Valid @ModelAttribute("userDetails") CustomerDetails customer, BindingResult br,Model m, HttpSession ses)
	{
		List<CustomerDetails> list= new ArrayList<CustomerDetails>();
		String custid=bankservice.saveCustomer(customer);
		System.out.println(custid);
		ses.setAttribute("custid", custid);
		list=bankservice.listCustomerDetails(custid);
		m.addAttribute("list", list);
		return "Customer";
	}

       @RequestMapping(value="/AccountDetails",method=RequestMethod.GET)
        public String displayAccount(@Valid @ModelAttribute("accountDetails") Account account, BindingResult br,Model m,HttpSession ses)
        {
                List<Account> list=new ArrayList<Account>();
                String cid=(String) ses.getAttribute("custid");
                account.setCustomerID(cid);
    			account.setAccountNumber(UserHelperClass.generateAccountNumber());
    			account.setBalance(50000.0);
                String accno=bankservice.saveAccount(account);
                ses.setAttribute("accno", accno);
                list=bankservice.listAccountDetails(cid);  
		        m.addAttribute("list", list);
		        //bankservice.savePayee(payee);
		        return "Account";
        }
       
       @RequestMapping(value="/AddPayeeDetails")
       public String displayPayee()
       {
    	   return "AddPayeeDetails";
       }
       
       @RequestMapping(value="/PayeeDetails", method = RequestMethod.POST)
       public String displayPayeeDetails(@RequestParam("name") String name,@RequestParam("accountNumber") String accountNumber,Model m,HttpServletRequest request,HttpSession ses)
       {
    	   int accresult=bankservice.validate(accountNumber);
    	   int nameresult=bankservice.validatename(name);
    	   if((accresult & nameresult)==1)
    	   {
    		   String cid=(String) ses.getAttribute("custid");
    		   //call a function using cid,nam,accountNumber to save it in database   
    		   List<Payee> list=new ArrayList<Payee>();
    		   bankservice.savePayee(name, cid, accountNumber);
    		   System.out.println(accountNumber);
    		   ses.setAttribute("toAccno",accountNumber);
    		   list=bankservice.listPayeeDetails(cid);
    		   m.addAttribute("list", list);    	  
    	   return "Payee";  
    	   }
    	   else
    		   return "AddPayeeDetails";   
       }  
    	  
       @RequestMapping(value="/TransferDetails")
       public String displaytransferdetails()
       {
    	   return "TransferDetails";
       }
          
       @RequestMapping(value="/TransactionDetails",method=RequestMethod.POST)
       public String displayTransactionDetails(@RequestParam("fromAccountNumber") String accountNumber,@RequestParam("toAccountNumber") String beneficiaryaccountNumber, @RequestParam("amount") double amount,Model m,HttpSession ses)
       {
    	   Transactions transaction1=new Transactions();
    	   Transactions transaction2=new Transactions();
    	   
    	   //String cid=(String) ses.getAttribute("custid");
    	   String ano=(String) ses.getAttribute("accno");
    	   String baccNo=(String) ses.getAttribute("toAccno");
    	   List<Transactions> list=new ArrayList<Transactions>();
    	   
    	   transaction1.setTransactionId(UserHelperClass.generateTransactionID());
    	   transaction1.setAccountNumber(ano);
    	   transaction1.setAmount(amount);
    	   String transtype=bankservice.getFromAccountNumber(ano);
    	   transaction1.setTransactionType(transtype);
    	   
    	   transaction2.setTransactionId(UserHelperClass.generateTransactionID());
    	   transaction2.setAccountNumber(baccNo);
    	   transaction2.setAmount(amount);
    	   String tTranstype=bankservice.getToAccountNumber(baccNo);
    	   transaction2.setTransactionType(tTranstype);
    	   bankservice.saveTransaction(transaction1);
    	   bankservice.saveTransaction(transaction2);
    	   list=bankservice.listTransactionDetails(ano);
    	   m.addAttribute("list", list);
    	   return "transactions";
       }
       
       /*
       public String displayTransaction(@Valid @ModelAttribute("transactionDetails") Transactions transaction, BindingResult br,Model m,HttpSession ses)
       {
    	   List<Transactions> list=new ArrayList<Transactions>();
    	   transaction.setTransactionId(UserHelperClass.generateTransactionID());
    	   String ano=(String) ses.getAttribute("accno");
    	   System.out.println(ano);
    	   transaction.setAccountNumber(ano);
    	   transaction.setAmount(5000);
    	   bankservice.saveTransaction(transaction);
    	   list=bankservice.listTransactionDetails();
    	   m.addAttribute("list", list);
    	   return "transactions"; 
       }
       */

}


/*
 * @RequestMapping(value="/submitform",method = RequestMethod.GET) public
 * ModelAndView display(@RequestParam("name")String name
 * ,@RequestParam("dob")LocalDate dob ,@RequestParam("phoneNumber")long
 * phoneNumber, @RequestParam("email")String
 * emailID, @RequestParam("address")String address
 * ,@RequestParam("aadhaarNumber")long aadhaarNumber, ModelAndView
 * m,HttpServletRequest req ) {
 * 
 * String s1=bankservice.saveCustomer(name, dob, phoneNumber, emailID, address,
 * aadhaarNumber); req.setAttribute("custID", s1);
 * 
 * List<CustomerDetails> cust=bankservice.listCustomerDetails();
 * req.setAttribute("customerdet", cust); m.setViewName("Customer"); return m; }
 */



/*
 * @RequestMapping(value = "/submitForm", method = RequestMethod.POST) public
 * String submitForm(@Valid @ModelAttribute("userDetails") User user,
 * BindingResult br) { if (br.hasErrors()) { return "reservation-page"; } else {
 */

/*
 * @RequestMapping(value = "/Employees", method = RequestMethod.GET) public
 * ModelAndView display(@RequestParam("firstname") String
 * name, @RequestParam("phoneNo") String phoneNo,
 * 
 * @RequestParam("mailId") String mailId, @RequestParam("dob") Date dob,
 * ModelAndView m) { Employee emp = new Employee(); emp.setName(name);
 * emp.setPhoneNo(phoneNo); emp.setMailId(mailId); emp.setDOB(dob); int sapId =
 * empService.saveEmployee(emp); List<Employee> employee =
 * empService.getEmployee(); empService.saveOrganisation(sapId, name);
 * List<Organisation> organisation = empService.getOrganisation(sapId);
 * empService.getProject(sapId); List<Project> project =
 * empService.getProject(sapId); m.addObject("employee", employee);
 * m.addObject("organisation", organisation); m.addObject("project", project);
 * m.setViewName("successfull"); return m; } }
 */


