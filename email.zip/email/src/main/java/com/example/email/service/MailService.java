package com.example.email.service;

public interface MailService {
	
	public void sendMail(String emailId,String text);

}
